In case you have any compilation issue, please change the character set to "Use Unicode Character Set" via:
project properties
	-> General
		->Character Set