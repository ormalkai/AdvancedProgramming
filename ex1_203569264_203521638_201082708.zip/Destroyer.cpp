#include "Destroyer.h"

Destroyer::Destroyer(char sign, int length, int value, _In_ WORD color) : Ship(sign, length, value, color)
{
}